package com.example.angelica.digitalcashbook;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {
    public static final String PREFS_NAME = "My Pref";
    private int saldo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        TextView Saldo = (TextView) findViewById(R.id.SaldoTextView);
        TextView Rekomendasi = (TextView) findViewById(R.id.RekomendasiTextView);
        TextView Saldo2 = (TextView) findViewById(R.id.SaldoTextView2);

        if (settings.contains("saldo"))
        {
            saldo = settings.getInt("saldo", 0);
        }else{
            saldo = 0 ;
        }
        double y = (0.045071403692093*saldo) + (-117.71403692093);
        NumberFormat nf = NumberFormat.getInstance();
        nf.setMaximumFractionDigits(2);
        String s = nf.format(y);

        Rekomendasi.setText("Rp. "+s+"");

        Saldo.setText("Rp. "+saldo+"");
    }

    public void onClickBtn (View v)
    {
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        EditText PemasukanText = (EditText) findViewById(R.id.PemasukanText);
        EditText PengeluaranText = (EditText) findViewById(R.id.PengeluaranText);
        TextView Saldo = (TextView) findViewById(R.id.SaldoTextView);
        TextView Rekomendasi = (TextView) findViewById(R.id.RekomendasiTextView);

        int masuk;
        int keluar;

        if (PemasukanText.getText().toString().equals(""))
        {
            masuk = 0;
        }else
        {
            masuk = Integer.parseInt(PemasukanText.getText().toString());
        }

        if (PengeluaranText.getText().toString().equals("")) {
            keluar = 0;
        }else
        {
            keluar = Integer.parseInt(PengeluaranText.getText().toString());
        }

        saldo+=masuk;
        saldo-=keluar;

        SharedPreferences.Editor editor = settings.edit();
        editor.putInt("saldo", saldo);
        editor.commit();


        Saldo.setText("Rp. "+saldo+"");

        Toast.makeText(this, "Saldo berhasil terupdate.", Toast.LENGTH_LONG).show();
        Intent intent = getIntent();
        finish();
        startActivity(intent);

        //rumus persamaan garis = (y-y1)/(y2-y1) = (x-x1)/(x2-x1)

    }
}
