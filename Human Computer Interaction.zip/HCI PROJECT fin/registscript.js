var username = document.getElementById("name").value;

function validation(){
    var username = document.getElementById("username").value;
    var email = document.getElementById("email").value;
    var male = document.getElementById("password").checked;
    var female = document.getElementById("male").checked;
    var password = document.getElementById("female").value;
    var message = ""


    if(isEmpty(name)) message = "name can't be empty";
    else if(isEmpty(email)) message = "email can't be empty";
    else if(isEmpty(password)) message = "password can't be empty";
    else if(!male && !female) message = "gender can't be empty";

   else if(
        email.indexOf("@") != email.lastIndexOf("@") ||

        email.startsWith("@") || 
        email.startsWith(".") || 
        email.endsWith("@") || 
        email.endsWith(".") || 

        !email.includes("@") || 
        !email.includes(".") || 

        email.includes("@.") ||
        email.includes(".@") ||
        email.includes("..") ||
        
        email.indexOf("@") > email.lastIndexOf(".")

    ) message = "email is not valid"
        
    alert(message);
}

function isEmpty(string){
    if(string == "") {
    return true;
    }else{
    return false;
    }
}